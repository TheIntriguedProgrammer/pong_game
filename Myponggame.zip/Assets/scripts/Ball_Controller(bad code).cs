using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball_spawner : MonoBehaviour
{   /// Declare rigidbody variable to manipulate later in code
   // private Rigidbody2D pongball;



    // Start is called before the first frame update
    void Start()
    {
        // gte the rigidbody component from the ball object and assigning our rigidbody variable
        // we can make the variable public and drag the rigidbody into the variable.

       // pongball = GetComponent<Rigidbody2D>();


        
    }

    
}
